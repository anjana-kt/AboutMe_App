package com.example.android.aboutme


    data class MyName(var name: String = "", var nickname: String = "")
